# Mitigram homework assignments

In this repository you can find various homework
assignments part of the interview process at 
Mitigram for software developers.

* [Threads](Threads/README.md) 🧵  
  An exercise that involves synchroninzing
  multiple threads.

* [Traveler](Traveler/README.md) 🤖  
  Our autonomous robot fleet have some 
  bugs.  
  Can you help us fix it?
